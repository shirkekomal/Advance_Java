//Application of employee
import java.util.*;
class employeeDemo
{
  private int empId;
  private String empName;
  void set(int empId,String empName)
  {
	 this.empId=empId;
	 this.empName=empName;
  }
 
  public String toString()
  {
	  return "Id:"+empId+" "+"Name:"+empName;
  }
  
  public int getempid()
  {
	  return this.empId;
  }
}
class mgr extends employeeDemo
{
 private float ta,td;
 void set(int id,String nm,float ta,float td)
 {
	set(id,nm);
	this.ta=ta;
	this.td=td;
 }
	public String toString()
	{
		return super.toString()+" "+"ta:"+ta+" "+"td:"+td;
	}
}
class clerk extends employeeDemo
{
	public float hra,da;
	void set(int id,String nm,float hra)
	{
		set(id,nm);
		this.hra=hra;
	}
	
	public String toString()
	{
		return super.toString()+" "+"hra:"+hra;
	}
}
class employee_App1
{
	public static void main(String args[])
	{
	  Scanner sc=new Scanner(System.in);	
	  employeeDemo e[]=new employeeDemo[10];
	  int t=-1;
	  do
	  {
		System.out.println("Enter 1:display\n2:Empdata\n3:managerData\n4:ClerkData\n5:searchEmp\n6:DeleteEmp\n7:Update\n0:exit");
        int ch=sc.nextInt();
				
			switch(ch)
			{
				case 1:
					for(int i=0;i<10;i++)
					{
						System.out.println(e[i]);
					}
					 break;
				case 2:
					System.out.println("Enter Id");
					int id=sc.nextInt();
					System.out.println("Enter name");
					String nm=sc.next();
					employeeDemo em=new employeeDemo();
					em.set(id,nm);
					e[++t]=em;
					 break;
				case 3:
					System.out.println("Enter id");
					id=sc.nextInt();
					System.out.println("Enter Name");
					nm=sc.next();
					System.out.println("Enter ta");
					float ta = sc.nextFloat();
					System.out.println("Enter td");
					float td = sc.nextFloat();
					mgr m=new mgr();
					m.set(id,nm,ta,td);
					e[++t]=m;
					 break;
				case 4:
					System.out.println("Enter id");
					id=sc.nextInt();
					System.out.println("Enter Name");
					nm=sc.next();
					System.out.println("Enter Hra");
					float hra = sc.nextFloat();
					clerk c=new clerk();
					c.set(id,nm,hra);
					e[++t]=c;
					 break;
				case 5:
					 System.out.println("Enter Empid to search");
					 id=sc.nextInt();
					 
					  for(int i=0;i<10;i++)
					 {
						 if(e[i].getempid()==id)
						 {
							System.out.println(e[i]);
						 }
					 }
						   System.out.println("Id not available");
					 break;
				case 6:
					System.out.println("Enter Empid to update");
					 id=sc.nextInt();
					 
					  for(int i=0;i<10;i++)
					 {
						 if(e[i].getempid()==id)
						 {
							 if(e[i] instanceof employeeDemo)
							 {
								e[i].set();
							 }
							 else if(e[i] instanceof mgr)
							 {
								 e[i].set();
							 }
						 }
					 }
						   System.out.println("Id not available");
					 break;
				case 7:
					 break;
				case 0:
					 System.exit(0);
				default:
					System.out.println("Wrong choice");
				
			}
	  }while(true);
	}
}
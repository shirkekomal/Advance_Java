import java.util.*;
class account
{
	private int accno;
	private String accholder;
	private float balance;
	void createAccount(int accno,String accholder,float balance)
	{
		this.accno=accno;
		this.accholder=accholder;
		this.balance=balance;
	}
	void accDetail()
	{
		System.out.println("Account"+accno);
		System.out.println("Account Holder"+accholder);
		System.out.println("Balance"+balance);
	}
	
	int getid()
	{
		return this.accno;
	}
	
	void deposite(float balance)
	{
		this.balance=this.balance+balance;
	}
	void Withdrwal(float balance)
	{
		if((this.balance-balance)>1000)
		{
			this.balance=this.balance-balance;
		}
		else
		{
			System.out.println("Insufficient balance");
		}
	}
}
class accountDemo
{
	public static void main(String args[])
	{
		account ad[]=new account[5];
		int t=-1;
		while(true)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Details \n1:CreateAcc\n2:AccDetails\n3:Deposite\n4:Withdrwal");
			int ch=sc.nextInt();
			switch(ch)
			{
				case 1:
					  System.out.println("Enter AccNO");
					  int an=sc.nextInt();
					  System.out.println("Enter Name");
					  String nm=sc.next(); 
					  System.out.println("Enter Amount");
					  float am=sc.nextFloat();
					  account a=new account();
					  a.createAccount(an,nm,am);
					  ad[++t]=a;
					  break;
				case 2:
				    System.out.println("Enter account no to Display");
					 int id=sc.nextInt();
					 for(int i=0;i<5;i++)
					 {
						 if(ad[i].getid()==id)
						 {
						   ad[i].accDetail();
						 }
					 }
					 System.out.println("account no not available");
					   break;
				case 3:
					  System.out.println("Enter account no to Deposite");
					  id=sc.nextInt();
					  for(int i=0;i<5;i++)
					  {	
						  if(id==ad[i].getid())
						  {
							  System.out.println("Enter amount to deposite");
							  am=sc.nextInt();
							  ad[i].deposite(am);
							  System.out.println("Deposited Successfully");
						  }
					  }
					  System.out.println("account no not available");
					  break;	 
				case 4:
					  System.out.println("Enter account no to Deposite");
					  id=sc.nextInt();
					  for(int i=0;i<5;i++)
					  {
						  if(id==ad[i].getid())
						  {
							  System.out.println("Enter amount to withdrawl");
							  am=sc.nextInt();
							  ad[i].Withdrwal(am);	 
							   System.out.println("Withdrwal Successfully");
						  }
					  }
					  break;
				default:
				      System.out.println("Wrong choice");
			}
		}
	}
}
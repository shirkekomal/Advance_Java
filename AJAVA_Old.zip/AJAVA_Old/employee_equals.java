//use of equals operator

class employeeDemo
{
  private int empId;
  private String empName;
  void set(int empId,String empName)
  {
	 this.empId=empId;
	 this.empName=empName;
  }
  void display()
  {
	  System.out.println(empId+" "+empName);
  }
  
  public boolean equals(Object obj)
  {
	  if(obj instanceof employeeDemo)
	  {
		employeeDemo e=(employeeDemo)obj;
		return this.empId==e.empId;
	  }
	  else
	  {
		  return false;
	  }
  }
}
class employee_equals
{
	public static void main(String args[])
	{
		employeeDemo e=new employeeDemo();
		e.set(1,"komal");
		e.display();
		
		employeeDemo e1=new employeeDemo();
		e1.set(1,"komal");
		e1.display();
		
		employeeDemo e2=e;
		System.out.println("----------------");
		System.out.println(e2.equals(e));
		System.out.println(e.equals(e1));
		
	}
}
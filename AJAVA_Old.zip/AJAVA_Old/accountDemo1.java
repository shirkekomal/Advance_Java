import java.util.*;
class account
{
	private int accno;
	private String accholder;
	private float balance;
	void createAccount(int accno,String accholder,float balance)
	{
		this.accno=accno;
		this.accholder=accholder;
		this.balance=balance;
	}
	void accDetail()
	{
		System.out.println("Account"+accno);
		System.out.println("Account Holder"+accholder);
		System.out.println("Balance"+balance);
	}
	void deposite(float balance)
	{
		this.balance=this.balance+balance;
	}
	void Withdrwal(float balance)
	{
		if((this.balance-balance)>1000)
		{
			this.balance=this.balance-balance;
		}
		else
		{
			System.out.println("Insufficient balance");
		}
	}
}
class accountDemo1
{
	public static void main(String args[])
	{
		account ad=new account();
		ad.createAccount(1234,"komal",11000);
		while(true)
		{
			Scanner sc=new Scanner(System.in);
			System.out.println("Enter Details \n1:AccDetails\n2:Deposite\n3:Withdrwal");
			int ch=sc.nextInt();
			switch(ch)
			{
				case 1:
					  ad.accDetail();
					   break;
				case 2:
					  System.out.println("Enter amount to deposite");
					  float am=sc.nextInt();
					  ad.deposite(am);
					  System.out.println("Deposited Successfully");
					  break;	 
				case 3:
					  System.out.println("Enter amount to withdrawl");
					  am=sc.nextInt();
					  if(am>0)
					  {
					   ad.Withdrwal(am);	 
					  }
					  break;
				default:
				      System.out.println("Wrong choice");
			}
		}
	}
}
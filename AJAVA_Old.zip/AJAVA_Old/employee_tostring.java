//use of tostring

class employeeDemo
{
  private int empId;
  private String empName;
  void set(int empId,String empName)
  {
	 this.empId=empId;
	 this.empName=empName;
  }
  void display()
  {
	  System.out.println(empId+" "+empName);
  }
  
  public String toString()
  {
	  return "Id:"+empId+" "+"name:"+empName;
  }
}
class employee_tostring
{
	public static void main(String args[])
	{
		employeeDemo e=new employeeDemo();
		e.set(1,"komal");
		
		employeeDemo e1=new employeeDemo();
		e1.set(2,"kunal");
		
		System.out.println(e);
		System.out.println(e1);
		
	}
}
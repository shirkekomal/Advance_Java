//use of equals operator
import java.util.*;
class employeeDemo
{
  private int empId;
  private String empName;
  void set(int empId,String empName)
  {
	 this.empId=empId;
	 this.empName=empName;
  }
 
  public String toString()
  {
	  return "Id:"+empId+" "+"Name:"+empName;
  }
  
}
class mgr extends employeeDemo
{
 private float ta,td;
 void set(int id,String nm,float ta,float td)
 {
	set(id,nm);
	this.ta=ta;
	this.td=td;
 }
	public String toString()
	{
		return super.toString()+" "+"ta:"+ta+" "+"td:"+td;
	}
}
class clerk extends employeeDemo
{
	public float hra,da;
	void set(int id,String nm,float hra)
	{
		set(id,nm);
		this.hra=hra;
	}
	
	public String toString()
	{
		return super.toString()+" "+"hra:"+hra;
	}
}
class employee_inheritance
{
	public static void main(String args[])
	{
		mgr e=new mgr();
		e.set(1,"komal",10,20);
		
		clerk c=new clerk();
		c.set(2,"kirti",40);
		
		System.out.println(e);
		System.out.println(c);
		
		System.out.println("----------------");
		Scanner sc=new Scanner("cdac");
		String nm=sc.next();
		System.out.println("Name:"+nm);
		System.out.println("Enter name");
		Scanner s=new Scanner(System.in);
		String s1=s.next();
		System.out.println("Name:"+s1);
	}
}
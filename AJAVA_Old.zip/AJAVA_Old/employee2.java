//use of static variable

class employeeDemo
{
  private int empId;
  private String empName;
  void set(int empId,String empName)
  {
	 this.empId=empId;
	 this.empName=empName;
  }
  void display()
  {
	  System.out.println(empId+" "+empName);
  }
}
class employee2
{
	public static void main(String args[])
	{
		employeeDemo e=new employeeDemo();
		e.set(1,"komal");
		e.display();
		
		employeeDemo e1=new employeeDemo();
		e1.set(1,"komal");
		e1.display();
		
		employeeDemo e2=e;
		System.out.println("----------------");
		System.out.println(e2==e);
		System.out.println(e==e1);
		
	}
}
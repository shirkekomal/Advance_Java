class employeeDemo
{
  private static int total;
  private int empId;
  private String empName;
  void set(int empId,String empName,int total)
  {
	 this.empId=empId;
	 this.empName=empName;
	 System.out.println(this);
	 employeeDemo.total=total;
  }
  void display()
  {
	  System.out.println(empId+" "+empName+" "+total);
  }
}
class employee
{
	public static void main(String args[])
	{
		employeeDemo e=new employeeDemo();
		e.set(1,"komal",1);
		e.display();
		System.out.println(e);
	}
}
//use of static variable

class employeeDemo
{
  private static int total;
  private int empId;
  private String empName;
  void set(int empId,String empName,int total)
  {
	 this.empId=empId;
	 this.empName=empName;
	 System.out.println(this);
	 employeeDemo.total=total;
  }
  void display()
  {
	  System.out.println(empId+" "+empName+" "+total);
  }
}
class employee1
{
	public static void main(String args[])
	{
		employeeDemo e=new employeeDemo();
		e.set(1,"komal",1);
		e.display();
		employeeDemo e1=new employeeDemo();
		e1.set(1,"kunal",2);
		e1.display();
		e.display();
		System.out.println(e);
		System.out.println(e1);
	}
}
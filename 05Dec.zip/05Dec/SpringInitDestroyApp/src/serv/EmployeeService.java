package serv;

public class EmployeeService {

 public EmployeeService() {
  System.out.println("empService() cons");
 }
 
 public EmployeeService(int i) {
  System.out.println("empService() cons param "+i);
 }

 public  void empServiceInit(){
  System.out.println("empServiceInit");
 }
 
 public void addEmployee(){
  System.out.println("addEmployee()");
 }
 
 public  void empServiceDestroy(){
  System.out.println("empServiceDestroy");
 }
 
 public static EmployeeService getInstance(){
  return new EmployeeService(100);
 }
 
}

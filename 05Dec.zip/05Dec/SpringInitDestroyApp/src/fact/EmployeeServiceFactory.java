package fact;

import serv.EmployeeService;

public class EmployeeServiceFactory {
 public static EmployeeService getEmployeeServiceInstance(){
  return new EmployeeService();
 }
}

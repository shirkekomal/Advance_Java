package fact;

import serv.EmployeeService;

public class EmployeeServiceFactory1 {
 public EmployeeService getEmployeeServiceInstance(){
  return new EmployeeService();
 }
}

package rep;

import dto.Employee;
import org.springframework.stereotype.Service;

@Service
public class EmployeeReport {

 public EmployeeReport() {
  System.out.println("EmployeeReport() cons");
 }
 
 
 
 public void generateReporst(Employee emp){
  System.out.println("generate Report : "+emp);
 }
}

package dao;

import dto.Employee;
import org.springframework.stereotype.Repository;


@Repository
public class EmployeeDao {

 public EmployeeDao() {
  System.out.println("EmployeeDao() cons");
 }
 
 public void insertEmployee(Employee emp){
  System.out.println("insert emp rec : "+emp);
 }
}

package p1;

import dto.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import serv.EmployeeService;

public class Main {

 public static void main(String[] args) {
  ApplicationContext appCntx = 
          new ClassPathXmlApplicationContext("cfg.xml");
  EmployeeService es = (EmployeeService)appCntx.getBean("empServ");
  System.out.println(es);
  es = (EmployeeService)appCntx.getBean("empServ");
  System.out.println(es);
 }
 
}

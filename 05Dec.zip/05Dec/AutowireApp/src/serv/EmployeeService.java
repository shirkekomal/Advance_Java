package serv;

import dao.EmployeeDao;
import dto.Employee;

public class EmployeeService {
 private EmployeeDao employeeDao,empDao;

 private EmployeeService() {
 }

 public EmployeeService(EmployeeDao employeeDao) {
  System.out.println("param cons");
  this.employeeDao = employeeDao;
 }

 
 public EmployeeDao getEmployeeDao() {
  return employeeDao;
 }

 public void setEmployeeDao(EmployeeDao employeeDao) {
  System.out.println("setEmployeeDao()");
  this.employeeDao = employeeDao;
 }

 public EmployeeDao getEmpDao() {
  return empDao;
 }

 public void setEmpDao(EmployeeDao empDao) {
  System.out.println("setEmpDao()");
  this.empDao = empDao;
 }
 
 
 
 public void addEmployee(Employee emp){
  System.out.println("add emp : "+emp);
  empDao.insertEmployee(emp);
  employeeDao.insertEmployee(emp);
 }
 
}

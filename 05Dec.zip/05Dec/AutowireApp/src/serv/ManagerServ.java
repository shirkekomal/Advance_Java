package serv;

import dao.EmployeeDao;
import dto.Employee;

public class ManagerServ {
 private EmployeeDao employeeDao,empDao;

 
 public EmployeeDao getEmployeeDao() {
  return employeeDao;
 }

 public void setEmployeeDao(EmployeeDao employeeDao) {
  System.out.println("setEmployeeDao() in manager");
  this.employeeDao = employeeDao;
 }

 public EmployeeDao getEmpDao() {
  return empDao;
 }

 public void setEmpDao(EmployeeDao empDao) {
  System.out.println("setEmpDao()");
  this.empDao = empDao;
 }
 
 
 
 public void addEmployee(Employee emp){
  System.out.println("add emp : "+emp);
//  empDao.insertEmployee(emp);
  employeeDao.insertEmployee(emp);
 }
}

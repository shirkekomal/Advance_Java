package serv;

import dao.EmployeeDao;
import dto.Employee;
import org.springframework.beans.factory.annotation.Autowired;
import rep.EmployeeReport;

public class EmployeeService {
 @Autowired
 private EmployeeDao employeeDao;
 @Autowired
 private EmployeeReport employeeReport;

 private EmployeeService() {
  System.out.println("EmployeeService() cons");
 }

 
 public EmployeeDao getEmployeeDao() {
  return employeeDao;
 }

 public void setEmployeeDao(EmployeeDao employeeDao) {
  System.out.println("setEmployeeDao()");
  this.employeeDao = employeeDao;
 }

 public EmployeeReport getEmployeeReport() {
  return employeeReport;
 }

 public void setEmployeeReport(EmployeeReport employeeReport) {
  this.employeeReport = employeeReport;
 }

 public void addEmployee(Employee emp){
  System.out.println("add emp : "+emp);
  employeeDao.insertEmployee(emp);
 }
 
 public void createReport(Employee emp){
  System.out.println("create emp report : "+emp);
  employeeReport.generateReporst(emp);
 }
 
}

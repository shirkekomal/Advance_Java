package p1;

import dto.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import serv.UserService;
import java.util.Scanner;

public class Main {
 private static ApplicationContext appCntx;
 
static {
 appCntx = 
          new ClassPathXmlApplicationContext("cfg.xml");
}
 public static void main(String[] args) {
  boolean flag = true;
  Scanner sc = new Scanner(System.in);
  do{
   System.out.println("0 to exit");
   System.out.println("1 to add user");
   byte ch = sc.nextByte();
   switch(ch){
    case 0 :
     System.exit(0);
    case 1 :
     insert(new User("abc", "ab", "admin", "2016-12-13"));
     break;
     default:
      System.out.println("wrong choice");
   }
  }while(flag);
  
 }
 private static void insert(User user){
  UserService us = (UserService)appCntx.getBean("userServ");
  us.addUser(user);
 }
 
}

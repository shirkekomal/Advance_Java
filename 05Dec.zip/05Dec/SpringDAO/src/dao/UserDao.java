package dao;

import dto.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.ArrayList;

@Repository
public class UserDao {
 
 @Autowired
 private JdbcTemplate jdbcTemplate;

 public JdbcTemplate getJdbcTemplate() {
  return jdbcTemplate;
 }

 public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
  this.jdbcTemplate = jdbcTemplate;
 }
 
 
 
 public void insertUser(User user){
  String q = "insert into user1(user_name,user_pass,user_role,join_date) values('"+user.getUserName()+"','"+user.getUserPass()+"','"+user.getUserRole()+"','"+user.getJoinDate()+"')";
  System.out.println(q);
  jdbcTemplate.update(q);
 }
  
 public void deleteUser(User user){
  String q = "delete from user1 where user_id = "+user.getUserId();
  System.out.println(q);
  jdbcTemplate.update(q);
 }
 
 public void updateUser(User user){
  String q = "update user1 set user_name = '"+user.getUserName()+"', user_pass = '"+user.getUserPass()+"',user_role='"+user.getUserRole()+"',join_date = '"+user.getJoinDate()+"' where user_id = "+user.getUserId();
  System.out.println(q);
  jdbcTemplate.update(q);
 }
 
 public List<User> selectUsers(){
  String q = "select * from user1";
  System.out.println(q);
 List<User> userList =  jdbcTemplate.query(q, new ResultSetExtractor<List<User>>() {

   @Override
   public List<User> extractData(ResultSet rs) throws SQLException, DataAccessException {
    List<User> ul = new ArrayList<User>();
    while(rs.next()){
     User u = new User();
     u.setUserId(rs.getInt("user_id"));
     u.setUserName(rs.getString("user_name"));
     u.setUserPass(rs.getString("user_pass"));
     u.setUserRole(rs.getString("user_role"));
     u.setJoinDate(rs.getString("join_date"));
     ul.add(u);
    }
    return ul;
   }
  });
 return userList;
 }
 
}

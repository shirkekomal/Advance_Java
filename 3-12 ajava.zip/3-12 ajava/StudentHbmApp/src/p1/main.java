package p1;

import dto.Student;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.*;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class main {
 private static SessionFactory sf;
 static{
  AnnotationConfiguration cfg
          = new AnnotationConfiguration();
  Properties props = new Properties();
  props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
  props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
  props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
  props.put("hibernate.connection.username", "cdac31");
  props.put("hibernate.connection.password", "cdac31");
  props.put("hibernate.hbm2ddl.auto", "update");
  props.put("hibernate.show_sql", "true");
  cfg.addProperties(props);
  cfg.addAnnotatedClass(Student.class);
  sf = cfg.buildSessionFactory();
 }

 public static void main(String[] args) throws ParseException {
  Scanner sc = new Scanner(System.in);
  boolean flag = true;
  do{
   System.out.println("0 to exit");
   System.out.println("1 to Insert");
   System.out.println("2 to Update");
   System.out.println("3 to Delete");
   System.out.println("4 to select all");
   System.out.println("5 to select Using name");
   
   byte ch = sc.nextByte();
   switch(ch){
    case 0 :
     System.exit(0);
    case 1 :
        System.out.println("Enter name: ");
        String nm=sc.next();
        System.out.println("Enter course: ");
        String mn=sc.next();
        System.out.println("Enter DOB: ");
        String da=sc.next();
        System.out.println("Enter Fee: ");
        double fe=sc.nextDouble();
        Insert(nm,mn,da,fe);
     break;
    case 2 :
        System.out.println("Enter id ");
        int i=sc.nextInt();
        System.out.println("Enter name to update: ");
        String n2=sc.next();
         System.out.println("Enter course: ");
        String c=sc.next();
         System.out.println("Enter DOB: ");
        String dat=sc.next();
         System.out.println("Enter Fee: ");
        double f=sc.nextDouble();
        Update1(i,n2,c,dat,f);
     break;
    case 3 :
        System.out.println("Enter name: ");
        String n=sc.next();
        Delete(n);
     break;
    case 4 :
      selectAll();
     break;
    case 5 :
         System.out.println("Enter name: ");
        String n1=sc.next();
     selectWhere(n1);
     break;
    default :
     System.out.println("wrong choice");
   }
  }while(flag);
  sf.close();
 }
 
  private static void Insert(String nm1,String mn1,String date1,double fe1)
  {
     Session s = sf.openSession();
     Transaction t = s.beginTransaction(); 
     try
     {
      SimpleDateFormat sf=new SimpleDateFormat("dd-MMM-yyyy");
      Date date2 = sf.parse(date1);
      Student s1=new Student(nm1,mn1,date2, fe1);
      s.save(s1);
     }catch(ParseException e)
     {
         e.printStackTrace();
     }
     t.commit();
     s.close();
     
  }
 
  
  
  private static void Update(int i,String n,String c,String d,double f)
  {
      Session s = sf.openSession();
      Transaction t = s.beginTransaction();
      try
     {
      SimpleDateFormat sf=new SimpleDateFormat("dd-MMM-yyyy");
      Date d1 = sf.parse(d);
      Student s1=(Student)s.get((Student.class),i);
      s1.setSname(n);
      s1.setCourse(c);
      s1.setDob(d1);
      s1.setFee(f);
   
//      Student s1=new Student(i,n, c,d1, f);
      s.update(s1);
     }catch(ParseException e)
     {
         e.printStackTrace();
     }
      t.commit();
      s.close();
  }
  
  private static void Update1(int i,String n,String c,String d,double f) throws ParseException
  {
      Session s = sf.openSession();
      Transaction t = s.beginTransaction();
      Query q = s.createQuery("update Student set sname=?,course=?,dob=?,fee=? where rno=?");
      
      q.setString(0, n);
      q.setString(1, c);
      SimpleDateFormat sf=new SimpleDateFormat("dd-m-yyyy");
      Date d1 = sf.parse(d);
      q.setDate(2, d1);
      q.setDouble(3, f);
      q.setInteger(4, i);
      
      q.executeUpdate();
      
      t.commit();
      s.close();
  }
  
  private static void Delete(String n)
  {
      Session s = sf.openSession();
      Transaction t = s.beginTransaction();
      Query q = s.createQuery("delete from Student where sname=?");
      q.setParameter(0,n);
      int res = q.executeUpdate();
        t.commit();
        s.close();
  }
  
 private static void selectAll(){
  Session s = sf.openSession();
  Transaction t = s.beginTransaction();
  Query q = s.createQuery("from Student");
  List<Student> l = q.list();
  for(Student e : l){
   System.out.println(e);
  }
  t.commit();
  s.close();
 }

 private static void selectWhere(String n){
  Session s = sf.openSession();
  Transaction t = s.beginTransaction();
   Query q = s.createQuery("from Student where sname=?");
    q.setParameter(0,n);
  List<Student> l = q.list();
  for(Student e : l){
   System.out.println(e);
  }
  t.commit();
  s.close();
 }
 

}

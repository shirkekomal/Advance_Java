
package p1;

import dto.Student;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Properties;
import java.util.Scanner;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.*;

public class Main {

        public static SessionFactory sf;
        
        static {
        AnnotationConfiguration cfg=new AnnotationConfiguration();
        
        Properties props = new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
        props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
        props.put("hibernate.connection.username", "cdac31");
        props.put("hibernate.connection.password", "cdac31");
        props.put("hibernate.hbm2ddl.auto", "update");
        props.put("hibernate.show_sql", "true");
        cfg.addProperties(props);
        cfg.addAnnotatedClass(Student.class);
        sf=cfg.buildSessionFactory();
        }
    public static void main(String[] args) throws ParseException {
        
        Scanner sc=new Scanner(System.in);
        boolean flag=true;
        do{
        
            System.out.println("0 to Exit");
            System.out.println("1 to Insert");
            System.out.println("2 to Update");
            System.out.println("3 to Delete");
            System.out.println("4 to select record using id");
            System.out.println("5 to Select All");
            
               byte ch=sc.nextByte();
               switch(ch)
               {
                   case 0:
                       System.exit(0);
                   case 1:
                       System.out.println("Enter name of student");
                       String nm=sc.next();
                       System.out.println("Enter course ");
                       String cs=sc.next();
                       System.out.println("Enter DOB of student");
                       String da=sc.next();
                       System.out.println("Enter fee of student");
                       float fe=sc.nextFloat();
                       
                       Insert(nm,cs,da,fe);
                       break;
                   case 2:
                        System.out.println("Enter id of student");
                       int id=sc.nextInt();
                       System.out.println("Enter name of student");
                       String nm1=sc.next();
                       System.out.println("Enter course ");
                       String cs1=sc.next();
                       System.out.println("Enter DOB of student");
                       String da1=sc.next();
                       System.out.println("Enter fee of student");
                       float fe1=sc.nextFloat();
                       
                       Update1(id,nm1,cs1,da1,fe1);
                        break;
                   case 3:
                       System.out.println("Enter name of student");
                       String nm2=sc.next();
                       Delete(nm2);
                       break;
                    case 4:
                        System.out.println("Enter id of student");
                       int id1=sc.nextInt();
                        SelectWhere(id1);
                        
                        break;
                    case 5:
                         selectAll();
                        break;
                   default:
                       System.out.println("Enter Wrong Choice");  
               }    
        }while (flag);
      sf.close();
    }
    
    public static void Insert(String n,String c,String dat1,float f) throws ParseException
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        
        SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
        Date d2=sd.parse(dat1);
        Student s1=new Student(n, c, d2, f);
        s.save(s1);
        t.commit();
        s.close();
        
    }
    
     public static void Update(int i,String n,String c,String dat1,float f) throws ParseException        
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        SimpleDateFormat sd=new SimpleDateFormat("yyyy-MM-dd");
        Date d2=sd.parse(dat1);
        Query q=s.createQuery("update Student set s_course=?, DATE=?, fee=?,s_name=? where srno=?");
       q.setInteger(0, i);
        q.setString(4, n);
        q.setString(1, c);
        q.setString(2, dat1);
        q.setFloat(3, f);
         int j= q.executeUpdate();
        t.commit();
        s.close();
        
    }
      public static void Delete(String n)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
         Query q=s.createQuery("delete from Student where s_name=?");
         q.setParameter(0,n);
         int res = q.executeUpdate();
        t.commit();
        s.close();
        
        
    }
       public static void SelectWhere(int id)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("From Student where srno=?");
            q.setParameter(0, id);
        List<Student> l=q.list();
       for(Student st: l )
       {
           System.out.println(st);
       }
        
        t.commit();
        s.close();
        
    }
     
       private static void Update1(int i,String n,String c,String d,double f) throws ParseException
  {
      Session s = sf.openSession();
      Transaction t = s.beginTransaction();
      Query q = s.createQuery("update Student set sname=?,course=?,date=?,fee=? where srno=?");
      
      q.setString(0, n);
      q.setString(1, c);
      SimpleDateFormat sf=new SimpleDateFormat("dd-m-yyyy");
      Date d1 = sf.parse(d);
      q.setDate(2, d1);
      q.setDouble(3, f);
      q.setInteger(4, i);
      
      q.executeUpdate();
      
      t.commit();
      s.close();
  }
  
         public static void selectAll() 
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("From Student");
        List<Student> l=q.list();
        for(Student st : l)
        {
            System.out.println(st);
        }
       
        t.commit();
        s.close();
        
    }
}

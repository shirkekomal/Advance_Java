
package dto;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@DiscriminatorValue(value = "mgr")
public class Manager extends Employee{

     private Float da,ta;
  
        public Manager() 
        {
         }

    public Manager(Float da, Float ta, int empId, String empName, String dept, float basicSal) {
        super(empId, empName, dept, basicSal);
        this.da = da;
        this.ta = ta;
    }

    public Float getDa() {
        return da;
    }

    public void setDa(Float da) {
        this.da = da;
    }

    public Float getTa() {
        return ta;
    }

    public void setTa(Float ta) {
        this.ta = ta;
    }

    @Override
    public void calNetSal() {
        super.calNetSal();
       netSal+=ta+da;
    }

    @Override
    public String toString() {
        return super.toString()+" "+ta+" "+da;
    }

}

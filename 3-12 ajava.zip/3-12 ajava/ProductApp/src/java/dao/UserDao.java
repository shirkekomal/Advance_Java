
package dao;

import conn.MyConnection;
import dto.User;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDao {
    
    private Connection con;

    public UserDao() {
       con=new MyConnection().getMyConnection();
    }
    

     public ArrayList<User> allUsers(){
  ArrayList<User> l = new ArrayList<User>();
   try {
   PreparedStatement s =con.prepareStatement("select prod_name from products");
  ResultSet rs  = s.executeQuery();
    while(rs.next()){
     User u = new User();
     //u.setProdId(rs.getInt(1));
     u.setProdName(rs.getString(1));
     l.add(u);
    }
   con.close();
  } catch (SQLException e) {
   e.printStackTrace();
  }
  return l;
 }
 

    
}

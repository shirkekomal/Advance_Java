
package p1;

import dto.Clerk;
import dto.Employee;
import dto.Manager;
import java.util.List;
import java.util.Properties;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;


public class Main1 {

    public static void main(String[] args) {
        AnnotationConfiguration cfg=new AnnotationConfiguration();
        Properties prop=new Properties();
        prop.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        prop.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
        prop.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
        prop.put("hibernate.connection.username", "cdac31");
        prop.put("hibernate.connection.password", "cdac31");
        prop.put("hibernate.hbm2ddl.auto", "update");
        prop.put("hibernate.show_sql", "true");
        
       // cfg.addProperties(prop);
        cfg.setProperties(prop);
        cfg.addAnnotatedClass(Employee.class);
        cfg.addAnnotatedClass(Manager.class);
        cfg.addAnnotatedClass(Clerk.class);
        
        SessionFactory sf=cfg.buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query Q=s.createQuery("from Employee");
        List <Employee> e=Q.list();
        for (Employee ele: e) {
            System.out.println(ele);
        }
        t.commit();
        s.close();
        sf.close();
    }
    
}

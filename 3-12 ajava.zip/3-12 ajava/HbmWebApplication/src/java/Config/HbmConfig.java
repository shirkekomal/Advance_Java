
package Config;

import dto.Student;
import java.util.Properties;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class HbmConfig 
{
 private static SessionFactory sf;

    public HbmConfig() {
    }
 
    public SessionFactory MyConfg()
    {
      if(sf==null || sf.isClosed())
      {
          AnnotationConfiguration cfg=new AnnotationConfiguration();
          Properties props=new Properties();
          props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
          props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
          props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
          props.put("hibernate.connection.username","cdac31");
          props.put("hibernate.connection.password", "cdac31");
          props.put("hibernate.hbm2ddl.auto", "update");
          props.put("hibernate.show_sql", "true");
          cfg.addProperties(props);
          cfg.addAnnotatedClass(Student.class);
          sf=cfg.buildSessionFactory();
      }
       return sf;
   }   
}

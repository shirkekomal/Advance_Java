
package dao;

import Config.HbmConfig;
import dto.Student;
import java.util.List;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class StudentDao 
{
  private static SessionFactory sf; 
    public StudentDao() 
    {
        sf=new HbmConfig().MyConfg();
    }
    
    public static void insert(Student std)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        s.save(std);
        t.commit();
        s.close();
    }
    
     public static void update(Student std)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q = s.createQuery("update Student set studName=?,course=?,dob=?,fee=? where studId=?");
        q.setString(0,std.getStudName());
        q.setString(1,std.getCourse());
        q.setDate(2,std.getDob());
        q.setFloat(3,std.getFee());
        q.setInteger(4, std.getStudId());
        q.executeUpdate();
        s.save(std);
        t.commit();
        s.close();
    }
     
      public static void delete(Student std)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Student s1=new Student( std.getStudId());
        s.delete(s1);
        t.commit();
        s.close();
    }
       public static List<Student> selectAll(Student std)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Student");
        List<Student> l=q.list();
        t.commit();
        s.close();
        return l;
    }
      
        public static Student selectId(Student std)
    {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        Query q=s.createQuery("from Student where studId=?"); 
        q.setParameter(0, std.getStudId());
        Student l=(Student)q.uniqueResult();
        t.commit();
        s.close();
        return l;
    }
}

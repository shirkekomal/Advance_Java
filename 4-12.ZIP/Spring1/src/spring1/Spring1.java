
package spring1;

import dto.Employee;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Spring1 {

 
    public static void main(String[] args) {
        ApplicationContext a = new ClassPathXmlApplicationContext("cfg.xml");
      
        Employee e = (Employee) a.getBean("komal12");
        System.out.println(e);
        
    }
    
}


package dto;

import java.util.List;
import java.util.Map;
import java.util.Properties;

public class Employee {
   private List<String> list;
   private Map<String,String> map;
   private Properties props;

    public Employee() {
    }

    public Employee(List<String> list, Map<String, String> map, Properties props) {
        this.list = list;
        this.map = map;
        this.props = props;
    }

    public List<String> getList() {
        return list;
    }

    public void setList(List<String> list) {
        this.list = list;
    }

    public Map<String, String> getMap() {
        return map;
    }

    public void setMap(Map<String, String> map) {
        this.map = map;
    }

    public Properties getProps() {
        return props;
    }

    public void setProps(Properties props) {
        this.props = props;
    }

    @Override
    public String toString() {
        return "Employee{" + "list=" + list + ", map=" + map + ", props=" + props + '}';
    }
   
    
    
    
    
}

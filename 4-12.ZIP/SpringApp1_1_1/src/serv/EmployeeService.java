package serv;

import dao.EmployeeDao;
import dto.Employee;

public class EmployeeService {
    private EmployeeDao empDao;

    public EmployeeService() {
    }

    public EmployeeService(EmployeeDao empDao) {
        this.empDao = empDao;
    }

    public EmployeeDao getEmpDao() {
        return empDao;
    }

    public void setEmpDao(EmployeeDao empDao) {
        this.empDao = empDao;
    }

    @Override
    public String toString() {
        return "EmployeeService{" + "empDao=" + empDao + '}';
    }
    
    public void showEmp(Employee emp){
        System.out.println("showEmp() in EmployeeService");
        empDao.insertEmp(emp);
    }
    
    
}

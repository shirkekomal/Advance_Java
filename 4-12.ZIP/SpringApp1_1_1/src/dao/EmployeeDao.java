package dao;

import dto.Employee;

public class EmployeeDao {
    public void insertEmp(Employee emp)
    {
        System.out.println("insertEmp() in EmployeeDao");
        System.out.println(emp);
    }
}

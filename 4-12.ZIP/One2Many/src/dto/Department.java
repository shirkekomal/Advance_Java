
package dto;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "dept13")
public class Department 
{
    @Id
    @GeneratedValue
    private int deptId;
    private String deptName;
    @OneToMany
    @JoinColumn(name = "deptId")
//    @BatchSize(size = 2)
//    @Fetch(FetchMode.JOIN)
//    @Fetch(FetchMode.SELECT)
      @Fetch(FetchMode.SUBSELECT)
    private Set<Employee> e=new HashSet<Employee>();

    public Department() {
    }

    
    public Department(int deptId) {
        this.deptId = deptId;
    }

    public Department(String deptName) {
        this.deptName = deptName;
    }

    public int getDeptId() {
        return deptId;
    }

    public void setDeptId(int deptId) {
        this.deptId = deptId;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public Set<Employee> getE() {
        return e;
    }

    public void setE(Set<Employee> e) {
        this.e = e;
    }

    @Override
    public String toString() {
        return "Department{" + "deptId=" + deptId + ", deptName=" + deptName + ", e=" + e + '}';
    }
   
    
}


package dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Parameter;

@Entity
@Table(name = "mgr")
public class Manager 
{
    @Id
    @GenericGenerator(name = "myGen",parameters = {@Parameter(name = "property",value = "dept")},strategy = "foreign")
    @GeneratedValue(generator = "myGen")
    private int mgrId;
    private String mgrName;
    @OneToOne
    private Department dept;

    public Manager() {
    }

    public Manager(int mgrId) {
        this.mgrId = mgrId;
    }

    public Manager(String mgrName, Department dept) {
        this.mgrName = mgrName;
        this.dept = dept;
    }
    
    public Manager(int mgrId, String mgrName, Department dept) {
        this.mgrId = mgrId;
        this.mgrName = mgrName;
        this.dept = dept;
    }

    public int getMgrId() {
        return mgrId;
    }

    public void setMgrId(int mgrId) {
        this.mgrId = mgrId;
    }

    public String getMgrName() {
        return mgrName;
    }

    public void setMgrName(String mgrName) {
        this.mgrName = mgrName;
    }

    public Department getDept() {
        return dept;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    @Override
    public String toString() {
        return "Manager{" + "mgrId=" + mgrId + ", mgrName=" + mgrName + ", dept=" + dept + '}';
    }
    
}

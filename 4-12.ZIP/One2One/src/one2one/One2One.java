
package one2one;

import dto.Department;
import dto.Manager;
import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class One2One {

   
    public static void main(String[] args) 
    {
        AnnotationConfiguration cfg=new AnnotationConfiguration();
        Properties props=new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
        props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
        props.put("hibernate.connection.username", "cdac31");
        props.put("hibernate.connection.password", "cdac31");
        props.put("hibernate.hbm2ddl.auto", "update");
        props.put("hibernate.show_sql", "true");
        cfg.setProperties(props);
        cfg.addAnnotatedClass(Department.class);
        cfg.addAnnotatedClass(Manager.class);
        
        SessionFactory sf=cfg.buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        
        Department d=new Department("it");
        Manager m=new Manager("sumya", d);
//        Department d1=new Department("it");
        Manager m1=new Manager("kirti", d);
        
        s.save(d);
        s.save(m); 
      //  s.save(m1); 
        t.commit();
        s.close();
        sf.close();
    }
    
}


package p1;

import dto.Subject;
import dto.Course;
import java.util.Properties;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;

public class Main {

    public static void main(String[] args) 
    {
        AnnotationConfiguration cfg=new AnnotationConfiguration();
        Properties props=new Properties();
        props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
        props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
        props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
        props.put("hibernate.connection.username", "cdac31");
        props.put("hibernate.connection.password", "cdac31");
        props.put("hibernate.hbm2ddl.auto", "update");
        props.put("hibernate.show_sql", "true");
        cfg.setProperties(props);
        cfg.addAnnotatedClass(Subject.class);
        cfg.addAnnotatedClass(Course.class);
        SessionFactory sf=cfg.buildSessionFactory();
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
      
        Subject s1=new Subject(101,"java");
        Subject s2=new Subject(102,"c++");
        Subject s3=new Subject(103,".net");
        
        Course c1=new Course(1,"cs");
        Course c2=new Course(2,"it");
        
        s1.getC().add(c2);
        s1.getC().add(c1);
        
        s1.getC().add(c1);
        s1.getC().add(c2);
        
        c1.getS().add(s3);
        c1.getS().add(s2);
        c1.getS().add(s1);
        
        c2.getS().add(s3);
        
        s.save(s1);
        s.save(c1);
        s.save(c2);
        t.commit();
        s.close();
        sf.close();
    }
    
}

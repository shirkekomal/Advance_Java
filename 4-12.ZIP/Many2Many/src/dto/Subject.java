
package dto;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "sub")
public class Subject 
{
 @Id
 @GeneratedValue
 private int subId;
 private String subName;
 @ManyToMany(mappedBy = "sub")
 private Set<Course> c=new HashSet<Course>();

    public Subject() {
    }

    public Subject(int subId) {
        this.subId = subId;
    }

    public Subject(int subId, String subName) {
        this.subId = subId;
        this.subName = subName;
    }

    public int getSubId() {
        return subId;
    }

    public void setSubId(int subId) {
        this.subId = subId;
    }

    public String getSubName() {
        return subName;
    }

    public void setSubName(String subName) {
        this.subName = subName;
    }

    public Set<Course> getC() {
        return c;
    }

    public void setC(Set<Course> c) {
        this.c = c;
    }

    @Override
    public String toString() {
        return "Subject{" + "subId=" + subId + ", subName=" + subName + ", c=" + c + '}';
    }

    
}

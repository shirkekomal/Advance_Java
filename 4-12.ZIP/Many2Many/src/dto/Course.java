
package dto;

import java.util.HashSet;
import java.util.Set;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "crs")
public class Course 
{
    @Id
    @GeneratedValue
    private int courseId;
    private String courseName;
    @ManyToMany
    @JoinTable(name = "course_subject1",joinColumns = {@JoinColumn(name = "courseId")},inverseJoinColumns = {@JoinColumn(name ="subId" )})
    private Set<Subject> s=new HashSet<Subject>();

    public Course() {
    }

    public Course(int courseId) {
        this.courseId = courseId;
    }

    public Course(int courseId, String courseName) {
        this.courseId = courseId;
        this.courseName = courseName;
    }

    public int getCourseId() {
        return courseId;
    }

    public void setCourseId(int courseId) {
        this.courseId = courseId;
    }

    public String getCourseName() {
        return courseName;
    }

    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public Set<Subject> getS() {
        return s;
    }

    public void setS(Set<Subject> s) {
        this.s = s;
    }

    @Override
    public String toString() {
        return "Course{" + "courseId=" + courseId + ", courseName=" + courseName + ", s=" + s + '}';
    }
    
    
}

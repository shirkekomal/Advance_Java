
package dto;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "emp12")
public class Employee {
    @Id
    @GeneratedValue
    private int empId;
    private String empName;
    @ManyToOne
    @JoinColumn(name = "deptId")
    Department dept;

    public Employee() {
    }

    public Employee(int empId) {
        this.empId = empId;
    }

    public Employee(String empName, Department dept) {
        this.empName = empName;
        this.dept = dept;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public Department getDept() {
        return dept;
    }

    public void setDept(Department dept) {
        this.dept = dept;
    }

    @Override
    public String toString() {
        return "Employee{" + "empId=" + empId + ", empName=" + empName + ", dept=" + dept + '}';
    }
    
}

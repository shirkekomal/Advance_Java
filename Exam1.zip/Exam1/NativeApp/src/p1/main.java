
package p1;

import dto.Employee;
import java.util.List;
import java.util.Properties;
import java.util.Scanner;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;


public class main {
    private static SessionFactory sf;
 static{
  AnnotationConfiguration cfg
          = new AnnotationConfiguration();
  Properties props = new Properties();
  props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
  props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
  props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
  props.put("hibernate.connection.username", "cdac31");
  props.put("hibernate.connection.password", "cdac31");
  props.put("hibernate.hbm2ddl.auto", "update");
  props.put("hibernate.show_sql", "true");
  cfg.addProperties(props);
  cfg.addAnnotatedClass(Employee.class);
  sf = cfg.buildSessionFactory();
 }

 public static void main(String[] args) {
//  Scanner sc = new Scanner(System.in);
//  boolean flag = true;
//  do{
//   System.out.println("0 to exit");
//   System.out.println("1 to select all");
//    byte ch = sc.nextByte();
//   switch(ch){
//    case 0 :
//     System.exit(0);
//    case 1 :
//     selectAll();
//     break;
//    default :
//     System.out.println("wrong choice");
//   }
//  }while(flag);
//  sf.close();
     
     selectAll();
     
     sf.close();
 }
    
     public static void selectAll()
     {
        Session s=sf.openSession();
        Transaction t=s.beginTransaction();
        SQLQuery q=s.createSQLQuery("select * from emp2");
        q.addEntity(Employee.class);
        List<Employee> l = q.list();
        for(Employee e:l)
        {
            System.out.println("--"+e);
        }
        t.commit();
        s.close();
        
     }
    
}


package dto;

public class Employee {
    private  int empId ;
    private String empName,dept;
    private float basicSal,netSal;

    public Employee(int empId, String empName, String dept, float basicSal) {
        this.empId = empId;
        this.empName = empName;
        this.dept = dept;
        this.basicSal = basicSal;
    }

    public int getEmpId() {
        return empId;
    }

    public void setEmpId(int empId) {
        this.empId = empId;
    }

    public String getEmpName() {
        return empName;
    }

    public void setEmpName(String empName) {
        this.empName = empName;
    }

    public String getDept() {
        return dept;
    }

    public void setDept(String dept) {
        this.dept = dept;
    }

    public float getBasicSal() {
        return basicSal;
    }

    public void setBasicSal(float basicSal) {
        this.basicSal = basicSal;
    }

    public float getNetSal() {
        return netSal;
    }

    public void setNetSal(float netSal) {
        this.netSal = netSal;
    }
    
  
    public void calNetSal()
    {
        this.netSal=basicSal;
    }
    @Override
    public String toString()
    {
        return empId+""+empName+""+dept+""+basicSal+""+netSal;
    }
    
}

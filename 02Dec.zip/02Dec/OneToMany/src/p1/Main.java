package p1;


import dto.Department;
import dto.Employee;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {
 public static void main(String[] args) {
  AnnotationConfiguration cfg = 
          new AnnotationConfiguration();
 Properties props = new Properties();
 props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
 props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
 props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/j2ee_db");
 props.put("hibernate.connection.username", "root");
 props.put("hibernate.connection.password", "Welcome@123");
 props.put("hibernate.hbm2ddl.auto", "update");
 props.put("hibernate.show_sql", "true");
 cfg.setProperties(props);
 
 cfg.addAnnotatedClass(Department.class);
 cfg.addAnnotatedClass(Employee.class);
  SessionFactory sf = cfg.buildSessionFactory();
  
  Session s  = sf.openSession();
  Transaction t = s.beginTransaction();
  
  Department dept = new Department("acc");
  
  Employee e1 = new Employee("pk");
  Employee e2 = new Employee("mn");
  
  dept.getEmps().add(e1);
  dept.getEmps().add(e2);
  
  s.save(dept);
  s.save(e1);
  s.save(e2);
  
  t.commit();
  s.close();
  sf.close();
 
 }
 
}

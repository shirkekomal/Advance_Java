package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;

@Entity
@Table(name = "emp12")
public class Employee {
 @Id
 @Column(name = "emp_id")
 @GeneratedValue
 private int empId;
 @Column(name = "emp_name",length = 20)
 private String empName;
 

 public Employee() {
 }

 public Employee(int empId) {
  this.empId = empId;
 }

 public int getEmpId() {
  return empId;
 }

 public void setEmpId(int empId) {
  this.empId = empId;
 }

 public Employee(String empName) {
  this.empName = empName;
 
 }

 
 
 public String getEmpName() {
  return empName;
 }

 public void setEmpName(String empName) {
  this.empName = empName;
 }

 @Override
 public String toString() {
  return empId+" "+empName;
 }
 
 
 
}

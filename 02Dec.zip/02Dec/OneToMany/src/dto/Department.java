package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;
import java.util.Set;
import java.util.HashSet;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import org.hibernate.annotations.BatchSize;
import org.hibernate.annotations.Fetch;
import org.hibernate.annotations.FetchMode;

@Entity
@Table(name = "dept12")

public class Department {
 @Id
 @GeneratedValue
 @Column(name = "dept_id")
 private int deptId; 
 @Column(name = "dept_name",length = 10)
 private String deptName;
 
 @OneToMany
 @JoinColumn(name = "dept_id")
// @Fetch(FetchMode.SUBSELECT)
 @BatchSize(size = 2)
 
 private Set<Employee> emps = new HashSet<Employee>();

 public Department() {
 }

 public Department(int deptId) {
  this.deptId = deptId;
 }

 public Department(String deptName) {
  this.deptName = deptName;
 }

 public int getDeptId() {
  return deptId;
 }

 public void setDeptId(int deptId) {
  this.deptId = deptId;
 }

 public String getDeptName() {
  return deptName;
 }

 public void setDeptName(String deptName) {
  this.deptName = deptName;
 }

 public Set<Employee> getEmps() {
  return emps;
 }

 public void setEmps(Set<Employee> emps) {
  this.emps = emps;
 }
 
 

 @Override
 public String toString() {
  return deptId+" "+deptName;
 }
 
}

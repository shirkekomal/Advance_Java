package p1;


import dto.Course;
import dto.Subject;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {
 public static void main(String[] args) {
  AnnotationConfiguration cfg = 
          new AnnotationConfiguration();
 Properties props = new Properties();
 props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
 props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
 props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/j2ee_db");
 props.put("hibernate.connection.username", "root");
 props.put("hibernate.connection.password", "Welcome@123");
 props.put("hibernate.hbm2ddl.auto", "update");
 props.put("hibernate.show_sql", "true");
 cfg.setProperties(props);
 
 cfg.addAnnotatedClass(Course.class);
 cfg.addAnnotatedClass(Subject.class);
 
  SessionFactory sf = cfg.buildSessionFactory();
  
  Session s  = sf.openSession();
  Transaction t = s.beginTransaction();
  
  Course c101 = new Course(101, "cs");
  Course c102 = new Course(102, "it");
  
  Subject s1 = new Subject(1, "java");
  Subject s2 = new Subject(2, "c");
  Subject s3 = new Subject(3, "spring");
  
  c101.getSubjects().add(s1);
  c101.getSubjects().add(s2);
  
  c102.getSubjects().add(s2);
  c102.getSubjects().add(s3);
  
  s1.getCourses().add(c101);
  
  s2.getCourses().add(c101);
  s2.getCourses().add(c102);
  
  s3.getCourses().add(c102);
  
  s.save(c101);
  s.save(c102);
  
  s.save(s1);
  s.save(s2);
  s.save(s3);
  
  
  t.commit();
  s.close();
  sf.close();
 
 }
 
}

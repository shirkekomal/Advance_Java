package dto;

import java.util.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "subject")
public class Subject {
 @Id
 @Column(name = "subject_id")
 private int subjectId;
 @Column(name = "subject_name",length = 20)
 private String subjectName;
 @ManyToMany(mappedBy = "subjects")
 private Set<Course> courses = new HashSet<Course>();

 public Subject() {
 }

 public Subject(int subjectId) {
  this.subjectId = subjectId;
 }

 public Subject(int subjectId, String subjectName) {
  this.subjectId = subjectId;
  this.subjectName = subjectName;
 }

 

 public int getSubjectId() {
  return subjectId;
 }

 public void setSubjectId(int subjectId) {
  this.subjectId = subjectId;
 }

 public String getSubjectName() {
  return subjectName;
 }

 public void setSubjectName(String subjectName) {
  this.subjectName = subjectName;
 }

 public Set<Course> getCourses() {
  return courses;
 }

 public void setCourses(Set<Course> courses) {
  this.courses = courses;
 }

 @Override
 public String toString() {
  return subjectId + " " + subjectName;
 }
 
 
 
}

package dto;
import java.util.*;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;
@Entity
@Table(name = "course")
public class Course {
 @Id
 @Column(name = "course_id")
 private int courseId; 
 @Column(name = "course_name",length = 20)
 private String courseName;
 @ManyToMany
 @JoinTable(name = "course_subject",joinColumns = {@JoinColumn(name = "course_id")},inverseJoinColumns = {@JoinColumn(name = "subject_id")})
 private Set<Subject> subjects = new HashSet<Subject>();

 public Course() {
 }

 public Course(int courseId) {
  this.courseId = courseId;
 }

 public Course(int courseId, String courseName) {
  this.courseId = courseId;
  this.courseName = courseName;
 }

 public int getCourseId() {
  return courseId;
 }

 public void setCourseId(int courseId) {
  this.courseId = courseId;
 }

 public String getCourseName() {
  return courseName;
 }

 public void setCourseName(String courseName) {
  this.courseName = courseName;
 }

 public Set<Subject> getSubjects() {
  return subjects;
 }

 public void setSubjects(Set<Subject> subjects) {
  this.subjects = subjects;
 }

 @Override
 public String toString() {
  return courseId + " " + courseName;
 }
 
}

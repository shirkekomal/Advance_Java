package dao;

import dto.Employee;
import fact.MyHbmSessionFact;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;


public class EmployeeDao {
 private SessionFactory sf;

 public EmployeeDao() {
  sf = new MyHbmSessionFact().getHbmSessionFact();
 }
 
 public void addEmp(Employee emp){
  Session s = sf.openSession();
  Transaction t = s.beginTransaction();
  emp.calNetSal();
  s.save(emp);
  t.commit();
  s.close();
 
 }
 
}

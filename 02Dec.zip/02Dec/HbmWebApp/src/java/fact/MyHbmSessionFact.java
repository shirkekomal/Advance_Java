package fact;

import dto.Employee;
import java.util.Properties;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.AnnotationConfiguration;

public class MyHbmSessionFact {
 private static SessionFactory sf;
 public SessionFactory getHbmSessionFact(){
  if(sf==null || sf.isClosed()){
   AnnotationConfiguration cfg
          = new AnnotationConfiguration();
  Properties props = new Properties();
  props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
  props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
  props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/j2ee_db");
  props.put("hibernate.connection.username", "root");
  props.put("hibernate.connection.password", "Welcome@123");
  props.put("hibernate.hbm2ddl.auto", "update");
  props.put("hibernate.show_sql", "true");
  cfg.addProperties(props);
  cfg.addAnnotatedClass(Employee.class);
  sf = cfg.buildSessionFactory();
  }
  return sf;
 }
}

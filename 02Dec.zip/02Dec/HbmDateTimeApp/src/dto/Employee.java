package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import org.hibernate.annotations.DynamicInsert;
import org.hibernate.annotations.DynamicUpdate;
import org.hibernate.annotations.LazyToOneOption;
import java.util.Date;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity(name = "em")
@Table(name = "emp_tempo")
@DynamicInsert(true)
@DynamicUpdate(true)
public class Employee {
 
 @Id
 @Column(name = "emp_id")
 private int empId;
 @Column(name = "emp_name",length = 15)
 private String empName;
 @Column(length = 7)
 private String dept;
 @Column(name = "basic_sal")
 private float basicSal;
 @Column(name = "net_sal")
 protected float netSal;
 
 @Column(name = "join_date")
 @Temporal(TemporalType.DATE)
 private Date joinDate;
 
 public Employee() {
 }

 public Employee(int empId) {
  this.empId = empId;
 }

 public Employee(int empId, String empName, String dept, float basicSal,Date joinDate) {
  this.empId = empId;
  this.empName = empName;
  this.dept = dept;
  this.basicSal = basicSal;
  this.joinDate = joinDate;
  
 }

 
 
 public int getEmpId() {
  return empId;
 }

 public void setEmpId(int empId) {
  this.empId = empId;
 }

 public String getEmpName() {
  return empName;
 }

 public void setEmpName(String empName) {
  this.empName = empName;
 }

 public String getDept() {
  return dept;
 }

 public void setDept(String dept) {
  this.dept = dept;
 }

 public float getBasicSal() {
  return basicSal;
 }

 public void setBasicSal(float basicSal) {
  this.basicSal = basicSal;
 }

 public float getNetSal() {
  return netSal;
 }

 public void setNetSal(float netSal) {
  this.netSal = netSal;
 }

 public Date getJoinDate() {
  return joinDate;
 }

 public void setJoinDate(Date joinDate) {
  this.joinDate = joinDate;
 }
 
 

 @Override
 public String toString() {
  return empId + " " + empName + " " + dept + " " + basicSal + " " + netSal;
 }
 
 public void calNetSal(){
  netSal = basicSal;
 }
 
}

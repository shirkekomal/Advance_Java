package p1;

import dto.Clerk;
import dto.Employee;
import dto.Manager;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

public class Main {
 public static void main(String[] args) {
  AnnotationConfiguration cfg = 
          new AnnotationConfiguration();
 Properties props = new Properties();
 props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
 props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
 props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/j2ee_db");
 props.put("hibernate.connection.username", "root");
 props.put("hibernate.connection.password", "Welcome@123");
 props.put("hibernate.hbm2ddl.auto", "update");
 props.put("hibernate.show_sql", "true");
 cfg.setProperties(props);
 
 cfg.addAnnotatedClass(Employee.class);
 cfg.addAnnotatedClass(Manager.class);
 cfg.addAnnotatedClass(Clerk.class);
 
  SessionFactory sf = cfg.buildSessionFactory();
  
  Session s  = sf.openSession();
  Transaction t = s.beginTransaction();
  
  Manager m = new Manager(700f, 800f, 3,"smith", "cs", 9999.99f);
  m.calNetSal();
  Clerk c = new Clerk(400f, 4,"mark", "it", 4000f);
  c.calNetSal();
  
  s.save(m);
  s.save(c);
  t.commit();
  s.close();
  sf.close();
 
 }
 
}

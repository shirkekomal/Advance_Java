package p1;

import dto.Clerk;
import dto.Employee;
import dto.Manager;
import org.hibernate.cfg.AnnotationConfiguration;
import java.util.Properties;
import org.hibernate.SQLQuery;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import java.util.List;
import org.hibernate.Query;

public class Main1 {
 public static void main(String[] args) {
  AnnotationConfiguration cfg = 
          new AnnotationConfiguration();
 Properties props = new Properties();
 props.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
 props.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
 props.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/j2ee_db");
 props.put("hibernate.connection.username", "root");
 props.put("hibernate.connection.password", "Welcome@123");
 props.put("hibernate.hbm2ddl.auto", "update");
 props.put("hibernate.show_sql", "true");
 cfg.setProperties(props);
 
cfg.addAnnotatedClass(Employee.class);
 cfg.addAnnotatedClass(Manager.class);
 cfg.addAnnotatedClass(Clerk.class);
 
  SessionFactory sf = cfg.buildSessionFactory();
  
  Session s  = sf.openSession();
  Transaction t = s.beginTransaction();
  Query q = s.createQuery("from Employee");
  List<Employee> el = q.list();
  for(Employee e : el){
   System.out.println(e);
  }
  t.commit();
  s.close();
  sf.close();
 
 }
 
}

package dto;

import javax.persistence.Column;
import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Inheritance;
import javax.persistence.InheritanceType;
import javax.persistence.Table;

@Entity
@Inheritance(strategy = InheritanceType.TABLE_PER_CLASS)
public class Employee {
 @Id
 @Column(name = "emp_id")
 private int empId;
 @Column(name = "emp_name",length = 20)
 private String empName;
 @Column(length = 5)
 private String dept;
 @Column(name = "basic_sal")
 private float basicSal;
 @Column(name = "net_sal")
 protected float netSal;

 public Employee() {
 }

 public Employee(int empId) {
  this.empId = empId;
 }

 public Employee(int empId,String empName, String dept, float basicSal) {
  this.empId = empId;
  this.empName = empName;
  this.dept = dept;
  this.basicSal = basicSal;
 }

 public int getEmpId() {
  return empId;
 }

 public void setEmpId(int empId) {
  this.empId = empId;
 }

 public String getEmpName() {
  return empName;
 }

 public void setEmpName(String empName) {
  this.empName = empName;
 }

 public String getDept() {
  return dept;
 }

 public void setDept(String dept) {
  this.dept = dept;
 }

 public float getBasicSal() {
  return basicSal;
 }

 public void setBasicSal(float basicSal) {
  this.basicSal = basicSal;
 }

 public float getNetSal() {
  return netSal;
 }

 public void setNetSal(float netSal) {
  this.netSal = netSal;
 }

 @Override
 public String toString() {
  return  empId + " " + empName + " " + dept + " " + basicSal + " " + netSal;
 }
 
 public void calNetSal(){
  netSal = basicSal;
 }
 
}

package dto;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "dept")
public class Department {
 @Id
 @GeneratedValue
 @Column(name = "dept_id")
 private int deptId; 
 @Column(name = "dept_name",length = 10)
 private String deptName;

 public Department() {
 }

 public Department(int deptId) {
  this.deptId = deptId;
 }

 public Department(String deptName) {
  this.deptName = deptName;
 }

 public int getDeptId() {
  return deptId;
 }

 public void setDeptId(int deptId) {
  this.deptId = deptId;
 }

 public String getDeptName() {
  return deptName;
 }

 public void setDeptName(String deptName) {
  this.deptName = deptName;
 }

 @Override
 public String toString() {
  return deptId+" "+deptName;
 }
 
}

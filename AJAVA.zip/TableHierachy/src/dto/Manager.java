
package dto;

import javax.persistence.DiscriminatorColumn;
import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;

@Entity
@DiscriminatorValue(value = "mgr")
public class Manager extends Employee{
  private float ta,da;

    public Manager(float ta, float da, int empId, String empName, String dept, Float basicSal) {
        super(empId, empName, dept, basicSal);
        this.ta = ta;
        this.da = da;
    }

    public Manager() {
    }

    public float getTa() {
        return ta;
    }

    public void setTa(float ta) {
        this.ta = ta;
    }

    public float getDa() {
        return da;
    }

    public void setDa(float da) {
        this.da = da;
    }
    
    
    @Override
    public void calNetSal() {
        super.calNetSal();
       netSal+=ta+da;
    }

    @Override
    public String toString() {
        return "Manager{" + "ta=" + ta + ", da=" + da + '}';
    }
  
    
    
}

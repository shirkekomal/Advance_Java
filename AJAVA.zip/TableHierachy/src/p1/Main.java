
package p1;

import dto.Clerk;
import dto.Employee;
import dto.Manager;
import java.util.Properties;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.AnnotationConfiguration;
 
public class Main {

    public static void main(String[] args) {
        AnnotationConfiguration cfg=new AnnotationConfiguration();
        Properties prop=new Properties();
            prop.put("hibernate.dialect", "org.hibernate.dialect.MySQLDialect");
            prop.put("hibernate.connection.driver_class", "com.mysql.jdbc.Driver");
            prop.put("hibernate.connection.url", "jdbc:mysql://localhost:3306/cdac31");
            prop.put("hibernate.connection.username", "cdac31");
            prop.put("hibernate.connection.password", "cdac31");
            prop.put("hibernate.hbm2ddl.auto", "update");
            prop.put("hibernate.show_sql", "true");
            cfg.addProperties(prop);
            cfg.addAnnotatedClass(Employee.class);
            cfg.addAnnotatedClass(Manager.class);
           // cfg.addAnnotatedClass(Clerk.class);
             cfg.addAnnotatedClass(Clerk.class);
            SessionFactory sf=cfg.buildSessionFactory();
            Session s=sf.openSession();
            Transaction t=s.beginTransaction();
            
              Manager e = new Manager(1121.9f,988.8f,12,"abhi", "MCA", 999.6f);
            e.calNetSal();
            s.save(e);
            Clerk c=new Clerk(2345.4f,6,"kiran","ME",1423.4f);
            c.calNetSal();
            s.save(c);
            
           t.commit();
           s.close();
           sf.close();
            
    }
    
}

package dto;

import javax.persistence.DiscriminatorValue;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity

public class Clerk extends Employee{
 
 private float hra;

 public Clerk() {
 }

 public Clerk(int empId) {
  super(empId);
 }

 public Clerk(float hra, String empName, String dept, float basicSal) {
  super(empName, dept, basicSal);
  this.hra = hra;
 }

 public float getHra() {
  return hra;
 }

 public void setHra(float hra) {
  this.hra = hra;
 }

 @Override
 public void calNetSal() {
  super.calNetSal(); 
  netSal += hra;
 }

 @Override
 public String toString() {
  return super.toString() + " " + hra;
 }
 
 
 
}

package p1;

import dto.User;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import serv.UserService;
import java.util.Scanner;
import java.util.List;

public class Main {
 private static ApplicationContext appCntx;
 
static {
 appCntx = 
          new ClassPathXmlApplicationContext("cfg.xml");
}
 public static void main(String[] args) {
  boolean flag = true;
  Scanner sc = new Scanner(System.in);
  do{
   System.out.println("0 to exit");
   System.out.println("1 to add user");
   System.out.println("2 user list");
   System.out.println("3 to del user");
   System.out.println("4 to update user");
   byte ch = sc.nextByte();
   switch(ch){
    case 0 :
     System.exit(0);
    case 1 :
     insert(new User("abc", "ab", "admin", "2016-12-13"));
     break;
    case 2 :
     select();
     break;
    case 3 :
      delete(6);
     break;
    case 4 :
     update(new User(6,"5555", "55", "555", "2017-12-13"));
     break;
     default:
      System.out.println("wrong choice");
   }
  }while(flag);
  
 }
 private static void insert(User user){
  UserService us = (UserService)appCntx.getBean("userServ");
  us.addUser(user);
 }
 private static void select(){
  UserService us = (UserService)appCntx.getBean("userServ");
  List<User> l = us.userList();
  for(User u : l){
   System.out.println(u);
  }
 }
 
 private static void delete(int userId){
  UserService us = (UserService)appCntx.getBean("userServ");
  us.removeUser(new User(userId));
 }
 private static void update(User user){
  UserService us = (UserService)appCntx.getBean("userServ");
  us.modifyUser(user);
 }
 
}

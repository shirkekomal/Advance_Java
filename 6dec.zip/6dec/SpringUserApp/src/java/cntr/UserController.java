package cntr;

import dto.User;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController {
 
 @RequestMapping(value = "/preplogin.htm")
 public String prepLoginPage(ModelMap model){
  model.put("user", new User());
  return "login";
 }
 
 @RequestMapping(value = "/prepreg.htm")
 public String prepRegPage(ModelMap model){
  model.put("user", new User());
  return "regform";
 }
 
 
}

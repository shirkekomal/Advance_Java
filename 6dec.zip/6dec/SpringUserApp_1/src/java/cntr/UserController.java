package cntr;

import dao.UserDao;
import dto.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class UserController {
 
 @Autowired
 private UserDao userDao;

 public UserDao getUserDao() {
  return userDao;
 }

 public void setUserDao(UserDao userDao) {
  this.userDao = userDao;
 }
 
 
 @RequestMapping(value = "/preplogin.htm")
 public String prepLoginPage(ModelMap model){
  model.put("user", new User());
  return "login";
 }
 
 @RequestMapping(value = "/prepreg.htm")
 public String prepRegPage(ModelMap model){
  model.put("user", new User());
  return "regform";
 }
 
 @RequestMapping(value = "/reg.htm")
 public String register(User user,ModelMap model){
  userDao.insertUser(user);
  model.put("user", new User());
  return "login";
 }
 
 
}
package dao;

import dto.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.ArrayList;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.orm.hibernate4.HibernateCallback;
import org.springframework.orm.hibernate4.HibernateTemplate;

@Repository
public class UserDao {
 
 @Autowired
 private HibernateTemplate hibernateTemplate;

 public HibernateTemplate getHibernateTemplate() {
  return hibernateTemplate;
 }

 public void setHibernateTemplate(HibernateTemplate hibernateTemplate) {
  this.hibernateTemplate = hibernateTemplate;
 }
 
 public void insertUser(User user)
 {
	 
  hibernateTemplate.execute(new HibernateCallback<List<User>>() {

   @Override
   public List<User> doInHibernate(Session sn) throws HibernateException {
    Transaction t = sn.beginTransaction();
    sn.save(user);
    t.commit();
    sn.flush();
    sn.close();
    return null;
   }
  });
 }
  
 public void deleteUser(User user){
  hibernateTemplate.execute(new HibernateCallback<List<User>>() {

   @Override
   public List<User> doInHibernate(Session sn) throws HibernateException {
    Transaction t = sn.beginTransaction();
    sn.delete(user);
    t.commit();
    sn.flush();
    sn.close();
    return null;
   }
  });
 }
 
 public void updateUser(User user){
 hibernateTemplate.execute(new HibernateCallback<List<User>>() {

   @Override
   public List<User> doInHibernate(Session sn) throws HibernateException {
    Transaction t = sn.beginTransaction();
//    User u = (User)sn.get(User.class, user.getUserId());
//    System.out.println(u);
    sn.update(user);
    t.commit();
    sn.flush();
    sn.close();
    return null;
   }
  });
 }
 
 public List<User> selectUsers(){
  List<User> userList = hibernateTemplate.execute(new HibernateCallback<List<User>>() {

   @Override
   public List<User> doInHibernate(Session sn) throws HibernateException {
    Transaction t = sn.beginTransaction();
    Query q = sn.createQuery("from User");
    List<User> l = q.list();
    t.commit();
    sn.flush();
    sn.close();
    return l;
   }
  });
 return userList;
 }
 
 
 
}

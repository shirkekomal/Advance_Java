package dao;

import dto.User;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.ResultSetExtractor;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.ArrayList;
import org.springframework.jdbc.core.RowMapper;

@Repository
public class UserDao {
 
 @Autowired
 private JdbcTemplate jdbcTemplate;

 public JdbcTemplate getJdbcTemplate() {
  return jdbcTemplate;
 }

 public void setJdbcTemplate(JdbcTemplate jdbcTemplate) {
  this.jdbcTemplate = jdbcTemplate;
 }
 
 
 
 public void insertUser(User user){
  String q = "insert into user1(user_name,user_pass,user_role,join_date) values(?,?,?,?)";
  
  System.out.println(q);
  jdbcTemplate.update(q,user.getUserName(),user.getUserPass(),user.getUserRole(),user.getJoinDate());
  
 }
  
 public void deleteUser(User user){
  String q = "delete from user1 where user_id = ?";
  System.out.println(q);
  jdbcTemplate.update(q,user.getUserId());
 }
 
 public void updateUser(User user){
  String q = "update user1 set user_name = ?, user_pass = ?,user_role=?,join_date = ? where user_id = ?";
  System.out.println(q);
  jdbcTemplate.update(q,user.getUserName(),user.getUserPass(),user.getUserRole(),user.getJoinDate(),user.getUserId());
 }
 
 public List<User> selectUsers(){
  String q = "select * from user1";
  System.out.println(q);
 List<User> userList =  jdbcTemplate.query(q,new RowMapper<User>() {

   @Override
   public User mapRow(ResultSet rs, int i) throws SQLException {
    User u = new User();
     u.setUserId(rs.getInt("user_id"));
     u.setUserName(rs.getString("user_name"));
     u.setUserPass(rs.getString("user_pass"));
     u.setUserRole(rs.getString("user_role"));
     u.setJoinDate(rs.getString("join_date"));
     return u;
   }
  });
 return userList;
 }
 
 
 
}

package serv;

import dao.UserDao;
import dto.User;
import java.util.List;

public class UserService {
 private UserDao userDao;

 public UserDao getUserDao() {
  return userDao;
 }

 public void setUserDao(UserDao userDao) {
  this.userDao = userDao;
 }
 
 public void addUser(User user){
  userDao.insertUser(user);
 }
 
 public void removeUser(User user){
  userDao.deleteUser(user);
 }
 
 public void modifyUser(User user){
  userDao.updateUser(user);
 }
 
 public List<User> userList(){
  return userDao.selectUsers();
 }
 
}

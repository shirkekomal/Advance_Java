package coll;
import java.util.*;
public class CollBean {
 private  Properties jdbcProperties;
 private List<String> mappingResoureces;
 private Map<String,String> jspScopes;

 public Properties getJdbcProperties() {
  return jdbcProperties;
 }

 public void setJdbcProperties(Properties jdbcProperties) {
  this.jdbcProperties = jdbcProperties;
 }

 public List<String> getMappingResoureces() {
  return mappingResoureces;
 }

 public void setMappingResoureces(List<String> mappingResoureces) {
  this.mappingResoureces = mappingResoureces;
 }

 public Map<String, String> getJspScopes() {
  return jspScopes;
 }

 public void setJspScopes(Map<String, String> jspScopes) {
  this.jspScopes = jspScopes;
 }
 
 
 
}

package msg;

public class MessageBean {
 private int msgNo;
 private String msg;

 public String getMsg() {
  
  return msg;
 }

 public void setMsg(String msg) {
  System.out.println("setMsg()");
  this.msg = msg;
 }

 public int getMsgNo() {
  return msgNo;
 }

 public void setMsgNo(int msgNo) {
  System.out.println("setMsgNo()");
  this.msgNo = msgNo;
 }
 
 
 
}

package dao;

import dto.Employee;

public class EmployeeDao {
 public void insertEmployee(Employee emp){
  System.out.println("insert emp recored");
  System.out.println(emp);
 }
}

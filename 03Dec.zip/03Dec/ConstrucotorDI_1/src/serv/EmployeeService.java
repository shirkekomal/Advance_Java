package serv;

import dao.EmployeeDao;
import dto.Employee;

public class EmployeeService {
 private EmployeeDao employeeDao;

 public EmployeeDao getEmployeeDao() {
  return employeeDao;
 }

 public void setEmployeeDao(EmployeeDao employeeDao) {
  this.employeeDao = employeeDao;
 }
 
 public void addEmployee(Employee emp){
  System.out.println("add employee");
  employeeDao.insertEmployee(emp);
 }
 
}

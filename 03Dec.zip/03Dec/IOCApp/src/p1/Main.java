package p1;
interface MyConn{
void getMyConn();
}
class MySqlCon implements MyConn{
 public void getMyConn(){
  System.out.println("mysql");
 }
}

class MyOracleCon implements MyConn{
 public void getMyConn(){
  System.out.println("oracle");
 }
}
class EmployeeDao{

 public EmployeeDao(MyConn m) {
  m.getMyConn();
 }
 
}
public class Main {

 public static void main(String[] args) {
  EmployeeDao dao1 = new EmployeeDao(new MySqlCon());
  EmployeeDao dao2 = new EmployeeDao(new MyOracleCon());
 }
 
}

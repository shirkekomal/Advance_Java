package msg;

public class MessageBean {
 private String msg;

 public String getMsg() {
  System.out.println("getMsg()");
  return msg;
 }

 public void setMsg(String msg) {
  System.out.println("setMsg()");
  this.msg = msg;
 }
 
 
}

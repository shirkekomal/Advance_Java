package serv;

import dao.EmployeeDao;
import dto.Employee;

public class EmployeeService {
 private int serviceNo;
 private EmployeeDao employeeDao;

 public EmployeeService() {
 }

 public int getServiceNo() {
  return serviceNo;
 }

 public void setServiceNo(int serviceNo) {
  System.out.println("setServiceNo");
  this.serviceNo = serviceNo;
 }
 
 public EmployeeDao getEmployeeDao() {
  return employeeDao;
 }

 public void setEmployeeDao(EmployeeDao employeeDao) {
  System.out.println("setEmployeeDao");
  this.employeeDao = employeeDao;
 }
 
 public void addEmployee(Employee emp){
  System.out.println("add employee");
  employeeDao.insertEmployee(emp);
 }
 
}

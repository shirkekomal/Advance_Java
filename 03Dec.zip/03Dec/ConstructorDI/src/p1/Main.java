package p1;

import msg.MessageBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main {
 public static void main(String[] args) {
  ApplicationContext appCntx = new ClassPathXmlApplicationContext("cfg.xml");
  MessageBean m = (MessageBean) appCntx.getBean("messageBean");
  System.out.println(m.getMsgNo());
  System.out.println(m.getMsg());
  m = (MessageBean) appCntx.getBean("messageBean1");
  System.out.println(m.getMsgNo());
  System.out.println(m.getMsg());
 }
 }

package p1;

import coll.CollBean;
import msg.MessageBean;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Main1 {
 public static void main(String[] args) {
  ApplicationContext appCntx = new ClassPathXmlApplicationContext("cfg1.xml");
  CollBean c = (CollBean)appCntx.getBean("coll");
  System.out.println(c.getJdbcProperties());
  System.out.println(c.getJspScopes());
  System.out.println(c.getMappingResoureces());
 }
 }

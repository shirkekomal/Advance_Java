package msg;

public class MessageBean {
 private int msgNo;
 private String msg;

 public MessageBean() {
  
 }

 public MessageBean(int msgNo) {
  System.out.println("int");
  this.msgNo = msgNo;
 }

 public MessageBean(int msgNo, String msg) {
  System.out.println("int String");
  this.msgNo = msgNo;
  this.msg = msg;
 }

 
 
 public String getMsg() {
  
  return msg;
 }

 public void setMsg(String msg) {
  System.out.println("setMsg()");
  this.msg = msg;
 }

 public int getMsgNo() {
  return msgNo;
 }

 public void setMsgNo(int msgNo) {
  System.out.println("setMsgNo()");
  this.msgNo = msgNo;
 }
 
 
 
}

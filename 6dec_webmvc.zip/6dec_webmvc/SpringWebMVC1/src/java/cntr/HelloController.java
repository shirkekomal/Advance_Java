package cntr;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class HelloController {
 private String msg;

 public String getMsg() {
  return msg;
 }

 public void setMsg(String msg) {
  this.msg = msg;
 }
 
 @RequestMapping(value = "/hello.htm")
 public String sayHello(ModelMap model){
  msg = "Hello Spring MVC Annotation";
  model.put("message", msg);
  return "success";
 }
 
}

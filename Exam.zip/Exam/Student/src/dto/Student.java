
package dto;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
@Entity
@Table(name = "std")
public class Student {
    @Id 
    @Column(name = "srno")
    @GeneratedValue(strategy = GenerationType.AUTO)
    private int srno;
    @Column(name = "s_name")
    private String sname;
    @Column(name = "s_course")
    private String course;
    @Column(name = "DATE")
    @Temporal(TemporalType.DATE)
    private Date date;
    @Column(name = "fee")
    private float fee;

    public Student() {
    }

    public Student(int srno) {
        this.srno = srno;
    }

    public Student(String sname, String course, Date date, float fee) {
        this.sname = sname;
        this.course = course;
        this.date = date;
        this.fee = fee;
    }

    public Student(int srno, String sname, String course, Date date, float fee) {
        this.srno = srno;
        this.sname = sname;
        this.course = course;
        this.date = date;
        this.fee = fee;
    }

    public int getSrno() {
        return srno;
    }

    public void setSrno(int srno) {
        this.srno = srno;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public float getFee() {
        return fee;
    }

    public void setFee(float fee) {
        this.fee = fee;
    }

    @Override
    public String toString() {
        return "Student{" + "srno=" + srno + ", sname=" + sname + ", course=" + course + ", date=" + date + ", fee=" + fee + '}';
    }
    
    
            
            
}


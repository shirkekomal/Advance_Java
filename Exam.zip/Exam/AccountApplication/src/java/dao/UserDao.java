
package dao;


import conn.MyConnection;
import dto.Account;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserDao {
    private Connection con;

    public UserDao() {
        
        con=new MyConnection().getMyConnection();
    }
    
    
    public void createUser(Account acc)
    {
        try
        {
            PreparedStatement s=con.prepareStatement("insert into account3 values(?,?,?,?,?,?,?,?,?)");
            s.setDouble(1, acc.getAccNo());
            s.setString(2, acc.getAccHolder());
            s.setFloat(3, acc.getBalance());
            s.setString(4, acc.getCreatedOn());
            s.setString(5, acc.getDob());
            s.setString(6, acc.getAddress());
            s.setString(7, acc.getBranch());
            s.setDouble(8, acc.getContactNo());
            s.setString(9, acc.getEmailId());
            
            s.execute();  
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }      
    }
    
  public ArrayList<Account> allUsers()
  {
      ArrayList<Account> l=new ArrayList<>();
       try
        {
            PreparedStatement s=con.prepareStatement("select accNo,accHolder from account3");
            ResultSet rs=s.executeQuery();
            
            while(rs.next())
            {
                Account a=new Account();
                a.setAccNo(rs.getDouble(1));
                a.setAccHolder(rs.getString(2));
                l.add(a);
            }
            
            s.execute();  
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }      
      return l;
  }
  
  public Account allUser(Account ac)
  {
      Account a=new Account();
       try
        {
            PreparedStatement s=con.prepareStatement("select * from account3 where accHolder=? ");
            s.setString(1, ac.getAccHolder());
            ResultSet rs=s.executeQuery();
            
            while(rs.next())
            { 
                a.setAccNo(rs.getDouble(1));
                a.setAccHolder(rs.getString(2));
                a.setBalance(rs.getFloat(3));
                a.setCreatedOn(rs.getString(4));
                a.setDob(rs.getString(5));
                a.setAddress(rs.getString(6));
                a.setBranch(rs.getString(7));
                a.setContactNo(rs.getDouble(8));
                a.setEmailId(rs.getString(9));  
            }
            
            s.execute();  
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }      
    return a;
  }
  
  
  
    
}

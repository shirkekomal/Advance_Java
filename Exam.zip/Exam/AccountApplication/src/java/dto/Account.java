
package dto;

public class Account {
    private double accNo;
   private String accHolder;
   private float balance;
   private String createdOn;
   private String dob;
   private String address;
   private String branch;
   private double contactNo;
   private String emailId;

    public Account() {
    }

    public Account(double accNo, String accHolder, float balance, String createdOn, String dob, String address, String branch, double contactNo, String emailId) {
        this.accNo = accNo;
        this.accHolder = accHolder;
        this.balance = balance;
        this.createdOn = createdOn;
        this.dob = dob;
        this.address = address;
        this.branch = branch;
        this.contactNo = contactNo;
        this.emailId = emailId;
    }

    public double getAccNo() {
        return accNo;
    }

    public void setAccNo(double accNo) {
        this.accNo = accNo;
    }

    public String getAccHolder() {
        return accHolder;
    }

    public void setAccHolder(String accHolder) {
        this.accHolder = accHolder;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    public String getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(String createdOn) {
        this.createdOn = createdOn;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public double getContactNo() {
        return contactNo;
    }

    public void setContactNo(double contactNo) {
        this.contactNo = contactNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @Override
    public String toString() {
        return "Account{" + "accNo=" + accNo + ", accHolder=" + accHolder + ", balance=" + balance + ", createdOn=" + createdOn + ", dob=" + dob + ", address=" + address + ", branch=" + branch + ", contactNo=" + contactNo + ", emailId=" + emailId + '}';
    }
   
   
}

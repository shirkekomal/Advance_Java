
package dao;
import dto.user;
import conn.myConnection;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;



public class UserDao 
{
    
    public Connection conn;

    public UserDao() 
    {
        conn=new myConnection().getMyConnection();
    }
    
    public ArrayList<user> allProduct()
    {
        ArrayList<user> l=new ArrayList<user>();
        try{
        PreparedStatement s=conn.prepareStatement("select prod_name from products");
            ResultSet rs=s.executeQuery();
            while(rs.next())
            {
                user u=new user();
               u.setProdName(rs.getString(1));
               l.add(u);
            }
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
        
        return l;
    }  
}

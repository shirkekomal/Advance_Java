
package dto;

public class Account 
{
    private int accNo;
    private String accHolder;
    private float bal;
    private String date;
    private String dob;
    private String add;
    private String branch;
    private double contactNo;
    private String emailId;

    public Account() {
    }

    public Account(int accNo, String accHolder, float bal, String date, String dob, String add, String branch, double contactNo, String emailId) {
        this.accNo = accNo;
        this.accHolder = accHolder;
        this.bal = bal;
        this.date = date;
        this.dob = dob;
        this.add = add;
        this.branch = branch;
        this.contactNo = contactNo;
        this.emailId = emailId;
    }

    public int getAccNo() {
        return accNo;
    }

    public void setAccNo(int accNo) {
        this.accNo = accNo;
    }

    public String getAccHolder() {
        return accHolder;
    }

    public void setAccHolder(String accHolder) {
        this.accHolder = accHolder;
    }

    public float getBal() {
        return bal;
    }

    public void setBal(float bal) {
        this.bal = bal;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getAdd() {
        return add;
    }

    public void setAdd(String add) {
        this.add = add;
    }

    public String getBranch() {
        return branch;
    }

    public void setBranch(String branch) {
        this.branch = branch;
    }

    public double getContactNo() {
        return contactNo;
    }

    public void setContactNo(double contactNo) {
        this.contactNo = contactNo;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

    @Override
    public String toString() {
        return "Account{" + "accNo=" + accNo + ", accHolder=" + accHolder + ", bal=" + bal + ", date=" + date + ", dob=" + dob + ", add=" + add + ", branch=" + branch + ", contactNo=" + contactNo + ", emailId=" + emailId + '}';
    }
    
    
}

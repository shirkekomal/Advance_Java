
package dao;

import conn.MyConnection;
import java.sql.Connection;


public class UserDao 
{

    private Connection con;
    public UserDao() 
    {
        con=new MyConnection().getMyConnection();
    }
    
    
    
}

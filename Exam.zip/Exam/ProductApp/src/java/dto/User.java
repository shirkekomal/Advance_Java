
package dto;

public class User 
{
    private int prodId;
    private String prodName;

    public User() {
    }

    public User(int prodId) {
        this.prodId = prodId;
    }

    public User(int prodId, String prodName) {
        this.prodId = prodId;
        this.prodName = prodName;
    }

    public int getProdId() {
        return prodId;
    }

    public void setProdId(int prodId) {
        this.prodId = prodId;
    }

    public String getProdName() {
        return prodName;
    }

    public void setProdName(String prodName) {
        this.prodName = prodName;
    }

    @Override
    public String toString() {
        return "User{" + "prodId=" + prodId + ", prodName=" + prodName + '}';
    }
    
}

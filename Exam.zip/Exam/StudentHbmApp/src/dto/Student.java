
package dto;

import java.util.Date;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

@Entity
@Table(name = "stud1")
public class Student 
{
  @Id
  @Column(name = "srno")
  @GeneratedValue(strategy = GenerationType.AUTO)
  private int rno;
  @Column(name = "s_name")
  private String sname;
  @Column(name = "s_course")
  private  String course;
  @Temporal(TemporalType.DATE)
  @Column(name = "DOB")
  private Date dob;
  @Column(name = "Fee")
  private Double fee;

    public Student() {
    }

    public Student(int rno) 
    {
        this.rno = rno;
    }

    public Student( String sname, String course, Date dob, Double fee) 
    {

        this.sname = sname;
        this.course = course;
        this.dob = dob;
        this.fee = fee;
    }

    public Student(int rno, String sname, String course, Date dob, Double fee) {
        this.rno = rno;
        this.sname = sname;
        this.course = course;
        this.dob = dob;
        this.fee = fee;
    }
    
    public int getRno() {
        return rno;
    }

    public void setRno(int rno) {
        this.rno = rno;
    }

    public String getSname() {
        return sname;
    }

    public void setSname(String sname) {
        this.sname = sname;
    }

    public String getCourse() {
        return course;
    }

    public void setCourse(String course) {
        this.course = course;
    }

    public Date getDob() {
        return dob;
    }

    public void setDob(Date dob) {
        this.dob = dob;
    }

    public Double getFee() {
        return fee;
    }

    public void setFee(Double fee) {
        this.fee = fee;
    }

   
    

    @Override
    public String toString() {
        return "Student{" + "rno=" + rno + ", sname=" + sname + ", course=" + course + ", dob=" + dob + ", fee=" + fee + '}';
    }
  
    
}

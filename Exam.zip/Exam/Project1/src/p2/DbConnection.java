
package p2;

import java.sql.CallableStatement;
import p1.*;
import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;


public class DbConnection {
    public static void main(String[] args) {
        try{
            Class.forName("com.mysql.jdbc.Driver");
            Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac31","cdac31","cdac31");
            CallableStatement s = con.prepareCall("{call komal()}");
            boolean b = s.execute();
                System.out.println(b); 
            con.close();
        }
        catch(ClassNotFoundException e){
            e.printStackTrace();
        }
        catch(SQLException e)
        {
            e.printStackTrace();
        }
    }
}

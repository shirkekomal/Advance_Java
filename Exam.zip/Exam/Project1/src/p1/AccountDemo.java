package p1;

import java.sql.Statement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class AccountDemo {

    public static void main(String[] args) {
        boolean flag = true;
        try {
            Class.forName("com.mysql.jdbc.Driver");
            Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac31", "cdac31", "cdac31");
            Statement s = con.createStatement();
            //boolean b=s.execute("create table account(accno integer primary key,accholder varchar(20),balance float,createdate date,status varchar(10) default 'active')");
            //System.out.println(b);
            while (flag) {
                Scanner sc = new Scanner(System.in);
           // int i=s.execute("insert into account values(101,'komal',1000,'1995-12-26','active')");
                //System.out.println(b);
                System.out.println("Enter your choice\n0:Exit\n1:Insert\n2:Delete\n3:Withdraw\n4:Deposite\n5:Block_Account\n6:showBet\n7:display_all");
                int ch = sc.nextInt();
                switch (ch) {
                    case 0:
                        System.exit(0);
                        break;
                    case 1:
                        System.out.println("Enter account no");
                        int accno = sc.nextInt();
                        System.out.println("Enter Name");
                        String accholder = sc.next();
                        System.out.println("Enter amount");
                        float amt = sc.nextFloat();
                        System.out.println("Enter creation date YYYY/MM/DD");
                        String date = sc.next();
                        System.out.println("Enter status");
                        String status = sc.next();
                        s.executeUpdate("insert into account values(" + accno + ",'" + accholder + "'," + amt + ",'" + date + "','" + status + "')");
                        break;
                    case 2:
                        System.out.println("Enter acc no to Delete");
                        int del = sc.nextInt();
                        s.executeUpdate("delete from account where accno=" + del + "");
                        System.out.println("Deleted Succesfully");
                        break;
                    case 3:
                        float b = 0;
                        System.out.println("Enter account no");
                        int no = sc.nextInt();
                         ResultSet rs=s.executeQuery("select accno from account where accno="+no+" and status!='block'");
                        if(rs.next()){
                           s.execute("select balance from account where accno=" + no + "");
                            rs = s.getResultSet();
                            while (rs.next()) {
                                b = rs.getFloat(1);
                            }
                            System.out.println("Balance "+b);
                            System.out.println("Enter amount to withdrawl");
                            float c = sc.nextFloat();
                            if ((b - c) > 1000) {
                                s.executeUpdate("update account set balance=" + (b - c) + "");
                            } else {
                                System.out.println("Insufficient balance");
                            }

                        } else {
                            System.out.println("Account does not exist");
                        }
                        break;
                    case 4:
                        float k=0;
                        System.out.println("Enter Account no");
                        no=sc.nextInt();
                        rs=s.executeQuery("select accno from account where accno="+no+" and status!='block'");
                        
                        if(rs.next())
                        {
                            System.out.println("Enter balance to deposite");
                            float bal=sc.nextFloat();
                            rs=s.executeQuery("select balance from account where accno="+no+"");
                           while(rs.next())
                           {
                               k=rs.getFloat(1);
                           }
                            s.executeUpdate("update account set balance="+(k+bal)+"");
                            System.out.println("Succesfully deposited"+(k+bal));
                        }
                        else
                        {
                            System.out.println("Account no not available/block");
                        }
                        break;
                    case 5:
                        System.out.println("Enter account no to block acount");
                        no=sc.nextInt();
                        rs=s.executeQuery("select accno from account where accno="+no+"");
                        if(rs.next())
                        {
                            s.executeUpdate("update account set status='block' where accno="+no+"");
                            System.out.println("Succesfully blocked"+no);
                        }
                        else
                        {
                            System.out.println("Account no not available");
                        }
                        break;
                    case 6:
                        rs=s.executeQuery("select * from account where balance>50000 and createdate between '2016/11/9' and '2016/12/31'");
                        while(rs.next())
                        {
                            System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getFloat(3)+" "+rs.getString(4)+" "+rs.getString(5));
                        
                        }
                        break;
                    case 7:
                        rs=s.executeQuery("select * from account");
                         while(rs.next())
                        {
                            System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getFloat(3)+" "+rs.getString(4)+" "+rs.getString(5));
                        
                        }
                        break;
                    default:
                        System.out.println("Wrong choice");
                }
            }
            con.close();
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

}

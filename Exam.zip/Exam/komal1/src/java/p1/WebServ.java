/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package p1;


import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author 160840320032
 */
@WebServlet(name = "WebServ", urlPatterns = {"/WebServ"})
public class WebServ extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     * 
     * 
     */
    
 
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        
        try (PrintWriter out = response.getWriter()) {
         /*   
          String nm=request.getParameter("Name");
          String pass=request.getParameter("Password");
          String gen=request.getParameter("Gender");
          String lang[]=request.getParameterValues("Language");
          String l = "";
            for( String a : lang){
                l += a;
                l += ",";
            }
              System.out.println("--"+l);
          String ct=request.getParameter("City");
        
        
            
        try{
         Class.forName("com.mysql.jdbc.Driver");
            Connection conn=DriverManager.getConnection("jdbc:mysql://localhost:3306/cdac31","cdac31","cdac31");
           
                PreparedStatement c=conn.prepareStatement("insert into register(name,password,gender,language,city) values(?,?,?,?,?)");
                c.setString(1,nm);
                c.setString(2,pass);
                c.setString(3,gen);
                c.setString(4,l);
                c.setString(5,ct);
                
                int i=c.executeUpdate();
                conn.close();
                */ 
               
          
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<head>");
            out.println("<title>Servlet Register Servlet</title>");            
            out.println("</head>");
            out.println("<body>");
            
           /* out.println("<h1> NAME: " + nm + "</h1>");
            out.println("<h1> PASSWORD: " + pass + "</h1>");
            out.println("<h1> GENDER: " + gen + "</h1>");
           
            out.println("<h1> LANGUAGE: " + l + "</h1>");
            
            out.println("<h1> CITY: " + ct + "</h1>");*/
            
            out.println("<h1> CITY: komal</h1>");
            out.println("</body>");
            out.println("</html>");
            
             //response.sendRedirect("login.html");
                /*
        }catch(ClassNotFoundException e)
                {
                e.printStackTrace();
                } catch(SQLException e)
                        {
                        e.printStackTrace();
                        }*/
    
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
